/* ============================================================
   poem.js – Gedicht-Editor (Formatieren, Speichern, Drucken)
   ============================================================ */

const PoemEditor = {
  _editor: null,
  _storageKey: '10Finger_poem',

  init(editorId) {
    this._editor = document.getElementById(editorId);
    this._setupToolbar();
    this._autoLoad();
  },

  _setupToolbar() {
    const boldBtn = document.getElementById('btnBold');
    const fontSize = document.getElementById('fontSizeSelect');
    const alignLeft = document.getElementById('btnAlignLeft');
    const alignCenter = document.getElementById('btnAlignCenter');
    const alignRight = document.getElementById('btnAlignRight');
    const saveBtn = document.getElementById('btnSavePoem');
    const loadBtn = document.getElementById('btnLoadPoem');
    const printBtn = document.getElementById('btnPrintPoem');

    // Bold
    boldBtn.addEventListener('click', () => {
      document.execCommand('bold', false, null);
      boldBtn.classList.toggle('active');
    });

    // Font size
    fontSize.addEventListener('change', () => {
      document.execCommand('fontSize', false, '7');
      const fontElements = this._editor.querySelectorAll('font[size="7"]');
      for (const el of fontElements) {
        const span = document.createElement('span');
        span.style.fontSize = fontSize.value;
        span.innerHTML = el.innerHTML;
        el.replaceWith(span);
      }
    });

    // Selection change → update toolbar state
    this._editor.addEventListener('click', () => this._updateToolbarState(boldBtn, alignLeft, alignCenter, alignRight));
    this._editor.addEventListener('keyup', () => this._updateToolbarState(boldBtn, alignLeft, alignCenter, alignRight));

    // Alignment
    alignLeft.addEventListener('click', () => {
      document.execCommand('justifyLeft');
      alignLeft.classList.add('active');
      alignCenter.classList.remove('active');
      alignRight.classList.remove('active');
    });
    alignCenter.addEventListener('click', () => {
      document.execCommand('justifyCenter');
      alignCenter.classList.add('active');
      alignLeft.classList.remove('active');
      alignRight.classList.remove('active');
    });
    alignRight.addEventListener('click', () => {
      document.execCommand('justifyRight');
      alignRight.classList.add('active');
      alignLeft.classList.remove('active');
      alignCenter.classList.remove('active');
    });

    // Save
    saveBtn.addEventListener('click', () => this._save());
    // Load
    loadBtn.addEventListener('click', () => this._autoLoad());
    // Print
    printBtn.addEventListener('click', () => {
      window.print();
      if (typeof Rewards !== 'undefined') Rewards.onPoemPrinted();
    });
  },

  _updateToolbarState(boldBtn, alignLeft, alignCenter, alignRight) {
    boldBtn.classList.toggle('active', document.queryCommandState('bold'));
    alignLeft.classList.toggle('active', document.queryCommandState('justifyLeft'));
    alignCenter.classList.toggle('active', document.queryCommandState('justifyCenter'));
    alignRight.classList.toggle('active', document.queryCommandState('justifyRight'));
  },

  _save() {
    const content = this._editor.innerHTML;
    try {
      localStorage.setItem(this._storageKey, content);
      this._flashSaveBtn();
      if (typeof Rewards !== 'undefined') Rewards.onPoemSaved();
    } catch { /* localStorage voll */ }
  },

  _flashSaveBtn() {
    const btn = document.getElementById('btnSavePoem');
    btn.textContent = '✓ Gespeichert';
    btn.style.background = '#40c057';
    btn.style.color = '#fff';
    btn.style.borderColor = '#40c057';
    setTimeout(() => {
      btn.textContent = 'Speichern';
      btn.style.background = '';
      btn.style.color = '';
      btn.style.borderColor = '';
    }, 1500);
  },

  _autoLoad() {
    try {
      const saved = localStorage.getItem(this._storageKey);
      if (saved) {
        this._editor.innerHTML = saved;
      }
    } catch { /* ignore */ }
  },

  autoSave() {
    try {
      const content = this._editor.innerHTML;
      if (content && content !== '<p><br></p>') {
        localStorage.setItem(this._storageKey, content);
      }
    } catch { /* ignore */ }
  }
};
