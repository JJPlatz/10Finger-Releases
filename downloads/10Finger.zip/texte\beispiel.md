# Die coolsten Sprüche der Klasse 7b

Chill mal deine Base, sagte Leon und grinste über beide Ohren. Der Matheunterricht war mal wieder der absolute Tiefpunkt des Tages. Aber hey, was soll's? Morgen ist auch noch ein Tag!

Frau Müller versuchte verzweifelt, die Klasse zum Schweigen zu bringen. Doch die 7b war heute in Feierlaune. Kein Wunder bei dem Wetter: Die Sonne knallte durch die Fenster, als gäbe es kein Morgen mehr.

Lena warf einen Papierflieger quer durch den Raum. Zack, Volltreffer an der Tafel! Die Klasse johlte. Sogar Tom, der sonst nie lachte, verschluckte sich fast an seinem Kaugummi.

In der großen Pause trafen sich alle am Kicker. Paul gegen Sarah, das Duell des Jahres. 5 zu 4 für Sarah, der Sieg war zum Greifen nah. Doch Paul konterte mit einem Wahnsinnsschuss und holte das Unentschieden.

Nach der Schule chatteten alle in der Klassengruppe. Die Hausaufgaben konnten warten. Erstmal musste das WM-Spiel analysiert werden. Deutschland hatte 3 zu 1 gegen Spanien gewonnen. Krass, oder?

Eins war sicher: Die 7b war die coolste Klasse der ganzen Schule. Keine Frage.
