/* ============================================================
   data.js – Tastatur-Layout, Finger-Farben, Lektionen
   ============================================================ */

const FINGERS = [
  { id: 0, name: 'Linker kleiner Finger',   color: '#FF6B6B', cssClass: 'finger-0' },
  { id: 1, name: 'Linker Ringfinger',       color: '#FF922B', cssClass: 'finger-1' },
  { id: 2, name: 'Linker Mittelfinger',     color: '#4DABF7', cssClass: 'finger-2' },
  { id: 3, name: 'Linker Zeigefinger',      color: '#51CF66', cssClass: 'finger-3' },
  { id: 4, name: 'Rechter Zeigefinger',     color: '#FFD43B', cssClass: 'finger-4' },
  { id: 5, name: 'Rechter Mittelfinger',    color: '#748FFC', cssClass: 'finger-5' },
  { id: 6, name: 'Rechter Ringfinger',      color: '#20C997', cssClass: 'finger-6' },
  { id: 7, name: 'Rechter kleiner Finger',  color: '#F783AC', cssClass: 'finger-7' },
  { id: 8, name: 'Daumen',                  color: '#ADB5BD', cssClass: 'finger-thumb' }
];

// Build a fast lookup: character → finger index
const CHAR_TO_FINGER = {};

function _map(chars, fingerId) {
  for (const c of chars) CHAR_TO_FINGER[c] = fingerId;
}

// Left pinky
_map(['^','1','q','a','y','<'], 0);
// Left ring
_map(['2','w','s','x'], 1);
// Left middle
_map(['3','e','d','c'], 2);
// Left index
_map(['4','5','r','t','f','g','v','b'], 3);
// Right index
_map(['6','7','z','u','h','j','n','m'], 4);
// Right middle
_map(['8','i','k',','], 5);
// Right ring
_map(['9','o','l','.'], 6);
// Right pinky
_map(['0','ß','´','p','ü','ö','ä','-','+','#'], 7);
// Space
_map([' '], 8);

// Uppercase variants point to same finger
for (const [ch, fid] of Object.entries(CHAR_TO_FINGER)) {
  CHAR_TO_FINGER[ch.toUpperCase()] = fid;
}
// Special: uppercase Ü, Ö, Ä (German has no direct uppercase mapping via toUpperCase for these?)
// Actually toUpperCase works for them: 'ü'.toUpperCase() = 'Ü'
// ß uppercase is SS, but key is still right pinky
CHAR_TO_FINGER['SS'] = 7;
CHAR_TO_FINGER['ẞ'] = 7;  // capital ß (Unicode)

function getFingerForChar(ch) {
  if (CHAR_TO_FINGER[ch] !== undefined) return CHAR_TO_FINGER[ch];
  // Fallback: check lowercase
  const lc = ch.toLowerCase();
  if (CHAR_TO_FINGER[lc] !== undefined) return CHAR_TO_FINGER[lc];
  return -1; // unknown
}

// ---- Keyboard Layout (QWERTZ) ----
// Each key: { label, char (optional, for lookup), finger, width }
// width classes: '' (normal), 'wide', 'wide2', 'wide3', 'wide4'

const KEYBOARD_ROWS = [
  // Row 0: Number row
  [
    { label: '^',  finger: 0 },
    { label: '1',  finger: 0 },
    { label: '2',  finger: 1 },
    { label: '3',  finger: 2 },
    { label: '4',  finger: 3 },
    { label: '5',  finger: 3 },
    { label: '6',  finger: 4 },
    { label: '7',  finger: 4 },
    { label: '8',  finger: 5 },
    { label: '9',  finger: 6 },
    { label: '0',  finger: 7 },
    { label: 'ß',  finger: 7 },
    { label: '´',  finger: 7 },
    { label: '⟵',  finger: 7, width: 'wide2' }  // Backspace
  ],
  // Row 1: Top letters
  [
    { label: 'Tab',   finger: 0, width: 'wide2' },
    { label: 'q',     finger: 0 },
    { label: 'w',     finger: 1 },
    { label: 'e',     finger: 2 },
    { label: 'r',     finger: 3 },
    { label: 't',     finger: 3 },
    { label: 'z',     finger: 4 },
    { label: 'u',     finger: 4 },
    { label: 'i',     finger: 5 },
    { label: 'o',     finger: 6 },
    { label: 'p',     finger: 7 },
    { label: 'ü',     finger: 7 },
    { label: '+',     finger: 7 },
    { label: '↵',     finger: 7, width: 'wide3' }  // Enter
  ],
  // Row 2: Home row
  [
    { label: '⇪',     finger: 0, width: 'wide3' },  // Caps Lock
    { label: 'a',     finger: 0 },
    { label: 's',     finger: 1 },
    { label: 'd',     finger: 2 },
    { label: 'f',     finger: 3 },
    { label: 'g',     finger: 3 },
    { label: 'h',     finger: 4 },
    { label: 'j',     finger: 4 },
    { label: 'k',     finger: 5 },
    { label: 'l',     finger: 6 },
    { label: 'ö',     finger: 6 },
    { label: 'ä',     finger: 7 },
    { label: '#',     finger: 7 }
  ],
  // Row 3: Bottom letters
  [
    { label: '⇧',     finger: 0, width: 'wide5' },  // Shift L
    { label: '<',     finger: 0 },
    { label: 'y',     finger: 0 },
    { label: 'x',     finger: 1 },
    { label: 'c',     finger: 2 },
    { label: 'v',     finger: 3 },
    { label: 'b',     finger: 3 },
    { label: 'n',     finger: 4 },
    { label: 'm',     finger: 4 },
    { label: ',',     finger: 5 },
    { label: '.',     finger: 6 },
    { label: '-',     finger: 7 },
    { label: '⇧',     finger: 7, width: 'wide' }    // Shift R
  ],
  // Row 4: Space bar row
  [
    { label: 'Strg',  finger: 0, width: 'wide' },
    { label: 'Win',   finger: -1, width: 'wide' },
    { label: 'Alt',   finger: 8, width: 'wide' },
    { label: '',      finger: 8, width: 'wide4' },   // Leertaste
    { label: 'AltGr', finger: 8, width: 'wide' },
    { label: 'Win',   finger: -1, width: 'wide' },
    { label: 'Menu',  finger: -1, width: 'wide' },
    { label: 'Strg',  finger: 7, width: 'wide' }
  ]
];

// Build lookup: key label/char → keyboard key object
const KEY_LOOKUP = {};
for (const row of KEYBOARD_ROWS) {
  for (const key of row) {
    const label = key.label.toLowerCase();
    if (label && label.length === 1 && !['^','´','+','#','<',',','.','-'].includes(label)) {
      KEY_LOOKUP[label] = key;
    }
    // Also register the label directly
    KEY_LOOKUP[key.label] = key;
    KEY_LOOKUP[key.label.toLowerCase()] = key;
  }
}

// ---- 20 Progressive Lessons ----
const LESSONS = [
  {
    id: 1,
    title: 'Grundstellung: asdf jklö',
    text: 'asdf jklö asdf jklö asdf jklö asdf jklö\n' +
          'asdf jklö asdf jklö asdf jklö asdf jklö\n' +
          'asdf jklö asdf jklö asdf jklö asdf jklö\n' +
          'asdf jklö asdf jklö asdf jklö asdf jklö\n' +
          'jklö asdf jklö asdf jklö asdf jklö asdf\n' +
          'jklö asdf jklö asdf jklö asdf jklö asdf\n' +
          'asdf jklö asdf jklö asdf jklö asdf jklö\n' +
          'jklö asdf jklö asdf jklö asdf jklö asdf'
  },
  {
    id: 2,
    title: 'Erweiterung: e und i',
    text: 'asdf jklö asdf jklö asdf jklö asdf jklö\n' +
          'asef jkli asef jkli asef jkli asef jkli\n' +
          'ease ilee ease ilee ease ilee ease ilee\n' +
          'die das lief schief die das lief schief\n' +
          'feld edel sie ideell edel feld sie ideell\n' +
          'jede diese einfiel jede diese einfiel\n' +
          'seife feile leise seife feile leise\n' +
          'edel fell seide edel fell seide edel fell'
  },
  {
    id: 3,
    title: 'Erweiterung: r und u',
    text: 'drei du dir eure rufe unsere drei du dir\n' +
          'rufe ure rufe ure rufe ure rufe ure\n' +
          'frau fuder ruder freude frau fuder ruder\n' +
          'rudi rief fredi freute rudi rief fredi\n' +
          'surren irren leere surren irren leere\n' +
          'edel rudi redet drei edel rudi redet\n' +
          'frei ural ruder edel frei ural ruder\n' +
          'rille dille ural rudi rille dille ural'
  },
  {
    id: 4,
    title: 'Erweiterung: t und z',
    text: 'taste zarte tief zu fest taste zarte tief\n' +
          'zitat tafel ziel tiere zitat tafel ziel\n' +
          'tur zu tief zerrt zu tur zu tief zerrt\n' +
          'fritz trug die latte fritz trug die latte\n' +
          'zu tief zu fest zerrt zu tief zu fest\n' +
          'tudel ziffer tadel zart tudel ziffer tadel\n' +
          'tier zu zart tiere tier zu zart tiere\n' +
          'trief luft ritze lutzel trief luft ritze'
  },
  {
    id: 5,
    title: 'Erweiterung: g und h',
    text: 'gut hagel geige hege gut hagel geige hege\n' +
          'hage geiz held gut hage geiz held gut\n' +
          'geld jagd gier hunger geld jagd hunger\n' +
          'hagel gut guter hagel gut guter hagel\n' +
          'halle glatt hell gelle halle glatt hell\n' +
          'gurke holz gitter held gurke holz gitter\n' +
          'hut gut gierig hitzig hut gut gierig hitzig\n' +
          'geh zu ihr da gehe hier zu ihr da gehe'
  },
  {
    id: 6,
    title: 'Erweiterung: w und o',
    text: 'woll wolle order oder frost wolle order\n' +
          'wort worf so wort worf so der worte\n' +
          'wohler oder oldes wohl wohler oldes wohl\n' +
          'worte sofort oder wolle worte sofort oder\n' +
          'lost wo der frosch lost wo der frosch\n' +
          'gross flore welt gross flore welt gross\n' +
          'wodka oder holz worte wodka oder holz\n' +
          'folge so oder wolle folge so oder wolle'
  },
  {
    id: 7,
    title: 'Erweiterung: c und Komma',
    text: 'circa, circa circa, circa, circa, circa\n' +
          'acht, dach, fach, noch, hoch, doch, ich\n' +
          'fechten, echter, der, die, das, dort,\n' +
          'clown, ach, ich, dich, sich, doch, noch\n' +
          'creme, cicero oder doch, creme, cicero\n' +
          'licht, dicht, echter, echter, licht, dicht\n' +
          'der dort, das hier, die doch, der dort\n' +
          'sicher, wache, suche, locher, sicher, dich'
  },
  {
    id: 8,
    title: 'Erweiterung: v und m',
    text: 'vom vogel am morgen via vom vogel am morgen\n' +
          'immer, malen, vater, mutter, immer, malen\n' +
          'mich, mir, vom, viel, mich, mir, vom, viel\n' +
          'viermal, mal vier, mal mehr ver, viel mehr\n' +
          'mutter, vater, vogel, milch, mutter, vater\n' +
          'voll, vermut, mit, voll, vermut, mit, voll\n' +
          'vom meer zum see, vom meer zum see, vom meer\n' +
          'viermal, vogelfrei, viermal, vogelfrei, viel'
  },
  {
    id: 9,
    title: 'Erweiterung: b und n',
    text: 'bin nun bei nein bald bin nun bei nein bald\n' +
          'neben, binden, nennen, baden, neben, baden\n' +
          'bunt, nicht, blau, nass, bunt, nicht, blau\n' +
          'nur, aber, ohne, ein, nur, aber, ohne, ein\n' +
          'brot, nudel, heute, brot, nudel, heute\n' +
          'binden, band, fund, binden, band, fund, nun\n' +
          'neben mir, bei dir, einmal, neben mir, bei\n' +
          'unten, blume, neben, unten, blume, neben, an'
  },
  {
    id: 10,
    title: 'Erweiterung: x und Punkt',
    text: 'max fix text exakt hexe. max fix text. hexe.\n' +
          'extrem. lexikon. export. extrem. lexikon.\n' +
          'boxer, mixer, nixe. boxer, mixer, nixe.\n' +
          'hex mal. fix. text. extra. hex mal. fix.\n' +
          'exakt. experte. extra. exakt. experte.\n' +
          'taxi. oxford. text. taxi. oxford. text.\n' +
          'max. fixe. box. max. fixe. box. extrem.\n' +
          'boxen. mixt. hexer. boxen. mixt. hexer.'
  },
  {
    id: 11,
    title: 'Erweiterung: q und p',
    text: 'quer. qual. pult. peter. quer. qual. pult.\n' +
          'quelle, paul, quer, apfel, quelle, paul.\n' +
          'paul pflugt. quasi prima. paul pflugt.\n' +
          'qual, preis, prima, quer, qual, preis, quer\n' +
          'peter quakt prima. peter quakt prima. quasi\n' +
          'april. quelle. post. april. quelle. post.\n' +
          'qualle, pult, prima, peter, qualle, pult,\n' +
          'quitt. patient. platz. quitt. patient.'
  },
  {
    id: 12,
    title: 'Erweiterung: y und ü',
    text: 'typisch, über, ypsilon, typisch, über, ypsilon\n' +
          'müde, mystik, üben, system, müde, mystik,\n' +
          'hymne, über, typ, hügel, hymne, über, typ\n' +
          'system, fülle, typisch, system, fülle, typ\n' +
          'yoga, müdig, typ, yoga, müdig, typ, yoga\n' +
          'üppig, mythen, hülle, üppig, mythen, hülle\n' +
          'gymnastik, früh, symbol, gymnastik, früh\n' +
          'typ, ypsilon, kühl, typ, ypsilon, kühl, typ'
  },
  {
    id: 13,
    title: 'Erweiterung: ä und ß',
    text: 'straße älter grüßen mäßig spaß straße älter\n' +
          'größer, mäßig, äpfel, grüßen, größer, mäßig\n' +
          'flöße, märz, spaß, flöße, märz, spaß, älter\n' +
          'kälte, stoßen, lärm, kälte, stoßen, lärm,\n' +
          'gräser, schließen, spät, gräser, schließen\n' +
          'mäßig, gießen, älter, mäßig, gießen, älter\n' +
          'schäfer, grüßen, märz, schäfer, grüßen, märz\n' +
          'floß, lärche, spaß, flöß, lärche, spaß, äste'
  },
  {
    id: 14,
    title: 'Großschreibung (Shift-Taste)',
    text: 'Das ist ein Auto. Der Hund und die Katze.\n' +
          'Die Mutter fragt: Wo warst Du denn Heute?\n' +
          'Peter und Paul gingen in den Wald Hinaus.\n' +
          'Am Sonntag Morgen schien die Sonne Hell.\n' +
          'Der Zug nach Hamburg Fährt um Acht Uhr.\n' +
          'Berlin ist eine Große und Schöne Stadt.\n' +
          'Im Sommer Fahren Wir immer ans Meer Zum Baden.\n' +
          'Was Machst Du denn da? Fragte der Vater.'
  },
  {
    id: 15,
    title: 'Ziffern 1 bis 5',
    text: '1 apfel 2 birnen 3 bananen 4 zitronen 5 eier\n' +
          '1 und 1 ist 2. 2 und 3 ist 5. 4 und 1 ist 5.\n' +
          '12345 54321 12345 54321 12345 54321 12345\n' +
          '15 24 33 42 51 15 24 33 42 51 15 24 33 42\n' +
          '1. punkt 2. punkt 3. punkt 4. punkt 5. punkt\n' +
          '345 125 234 451 345 125 234 451 345 125\n' +
          '234 512 345 123 234 512 345 123 234 512\n' +
          '123 45 321 54 123 45 321 54 123 45 321'
  },
  {
    id: 16,
    title: 'Ziffern 6 bis 0',
    text: '6 äpfel 7 birnen 8 bananen 9 zitronen 0 eier\n' +
          '6 und 4 ist 10. 7 und 8 ist 15. 9 und 0 ist 9.\n' +
          '67890 09876 67890 09876 67890 09876 67890\n' +
          '60 77 88 99 00 60 77 88 99 00 60 77 88 99\n' +
          '6. punkt 7. punkt 8. punkt 9. punkt 0. punkt\n' +
          '789 601 678 900 789 601 678 900 789 601\n' +
          '987 60 876 09 987 60 876 09 987 60 876\n' +
          '1024 2048 4096 8192 1024 2048 4096 8192'
  },
  {
    id: 17,
    title: 'Sonderzeichen',
    text: '+ plus - minus # raute < kleiner > größer\n' +
          'punkt. komma, strich; doppel: frage? ruf!\n' +
          'apfel + birne = obst. hallo - welt = nichts.\n' +
          '#tag #nummer #gitter. #tag #nummer #gitter.\n' +
          '1 < 2 und 3 > 2. 1 < 2 und 3 > 2. 1 < 2.\n' +
          '3 + 4 = 7. 9 - 5 = 4. 8 + 1 = 9. 6 - 3 = 3.\n' +
          'hallo! wie gehts? gut! und dir? auch gut!\n' +
          'a < b < c > x. a < b < c > x. a < b < c.'
  },
  {
    id: 18,
    title: 'Gemischte Wörter',
    text: 'Programmierer Schmetterling Wanderweg Blumenstrauß\n' +
          'Eichhörnchen Zauberkunst Märchenwald Sonnenblume\n' +
          'Schokolade Erdbeereis Zitronenfalter Apfelkuchen\n' +
          'Ritterburg Drachenflug Abenteuer Schatzkarte\n' +
          'Geheimnisvoll Wunderlampe Sternenhimmel Goldfisch\n' +
          'Pusteblume Regenbogen Kuscheltier Zauberwald\n' +
          'Kindergarten Purzelbaum Murmeltier Schneeball\n' +
          'Guten Morgen liebe Sonne. Hallo du schöne Welt.'
  },
  {
    id: 19,
    title: 'Sätze',
    text: 'Der frühe Vogel fängt den Wurm, so sagt man.\n' +
          'Heute backe ich einen großen leckeren Kuchen.\n' +
          'Die Kinder spielten fröhlich im bunten Garten.\n' +
          'Morgen früh um 7 Uhr klingelt mein Wecker laut.\n' +
          'Im Sommer fahren wir jedes Jahr ans blaue Meer.\n' +
          'Der kleine Hund lief schnell über die grüne Wiese.\n' +
          'Meine Oma kocht die beste Suppe der ganzen Welt.\n' +
          'Langsam schloss sie die Tür und ging leise hinaus.'
  },
  {
    id: 20,
    title: 'Langer Text',
    text: 'Es war einmal ein kleiner Drache namens Funki.\n' +
          'Funki lebte in einer großen, alten Burgruine.\n' +
          'Jeden Tag übte er das Feuerspucken mit seinem\n' +
          'Großvater, der schon 300 Jahre alt war. Doch\n' +
          'Funki konnte noch kein richtiges Feuer spucken.\n' +
          'Statt Flammen kamen nur bunte Funken aus seinem\n' +
          'Maul. Die anderen Drachen lachten ihn oft aus.\n' +
          'Aber Funki gab nicht auf. Er übte jeden Morgen\n' +
          'und jeden Abend. Eines Tages geschah es dann:\n' +
          'Ein wunderschöner, goldener Feuerstrahl schoss\n' +
          'aus seinem Mund! Alle Drachen staunten. Funkis\n' +
          'Feuer war das schönste Feuer, das sie je gesehen\n' +
          'hatten. Von da an war Funki der stolzeste kleine\n' +
          'Drache im ganzen Land. Ende der Geschichte.'
  }
];
