/* ============================================================
   rewards.js – Belohnungssystem: Sterne, Erfolge, Feiern
   ============================================================ */

const Rewards = {
  _key: '10Finger_rewards',
  _data: null,

  // Achievement-Definitionen
  _achievements: [
    { id: 'first_lesson',   icon: '🌟', title: 'Erster Schritt',       desc: 'Eine Lektion abgeschlossen' },
    { id: 'five_lessons',   icon: '🔥', title: 'Am Ball geblieben',    desc: '5 Lektionen geschafft' },
    { id: 'ten_lessons',    icon: '💪', title: 'Dranbleiber',           desc: '10 Lektionen geschafft' },
    { id: 'all_lessons',    icon: '👑', title: 'Tastatur-König',       desc: 'Alle 20 Lektionen gemeistert' },
    { id: 'perfect_score',  icon: '💎', title: 'Perfekt!',             desc: '100% Genauigkeit in einer Lektion' },
    { id: 'speed_demon',    icon: '⚡', title: 'Turbo-Finger',          desc: 'Über 100 Anschläge/Minute' },
    { id: 'combo_master',   icon: '🎯', title: 'Kombot-Meister',       desc: '30er Kombot im Spiel erreicht' },
    { id: 'highscore',      icon: '🏆', title: 'Highscore!',           desc: 'Neuen Punkte-Rekord aufgestellt' },
    { id: 'streak_3',       icon: '📅', title: 'Serientäter',          desc: '3 Tage in Folge geübt' },
    { id: 'streak_7',       icon: '🗓️', title: 'Wochen-Champion',       desc: '7 Tage in Folge geübt' },
    { id: 'poem_saved',     icon: '📝', title: 'Dichterling',           desc: 'Ein Gedicht gespeichert' },
    { id: 'poem_printed',   icon: '🖨️', title: 'Veröffentlicht',        desc: 'Ein Gedicht ausgedruckt' },
  ],

  init() {
    this._load();
  },

  _load() {
    try {
      const raw = localStorage.getItem(this._key);
      this._data = raw ? JSON.parse(raw) : { earned: [], streak: 0, lastDate: null, lessonCount: 0 };
    } catch {
      this._data = { earned: [], streak: 0, lastDate: null, lessonCount: 0 };
    }
  },

  _save() {
    try { localStorage.setItem(this._key, JSON.stringify(this._data)); } catch {}
  },

  // ---- Streak Tracking ----
  _updateStreak() {
    const today = new Date().toISOString().split('T')[0];
    if (this._data.lastDate === today) return this._data.streak;

    const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
    if (this._data.lastDate === yesterday) {
      this._data.streak++;
    } else if (this._data.lastDate !== today) {
      this._data.streak = 1;
    }
    this._data.lastDate = today;
    this._save();

    // Check streak achievements
    if (this._data.streak === 3) this._earn('streak_3');
    if (this._data.streak === 7) this._earn('streak_7');

    return this._data.streak;
  },

  getStreak() {
    return this._data.streak || 0;
  },

  // ---- Lesson Completion ----
  celebrateLesson(stats) {
    this._data.lessonCount = (this._data.lessonCount || 0) + 1;
    const streak = this._updateStreak();
    this._save();

    // Check achievements
    if (this._data.lessonCount >= 1) this._earn('first_lesson');
    if (this._data.lessonCount >= 5) this._earn('five_lessons');
    if (this._data.lessonCount >= 10) this._earn('ten_lessons');
    if (this._data.lessonCount >= 20) this._earn('all_lessons');
    if (stats.accuracy === 100) this._earn('perfect_score');
    if (stats.cpm >= 100) this._earn('speed_demon');

    // Show celebration
    const stars = stats.accuracy === 100 ? 3 : stats.accuracy >= 95 ? 2 : stats.accuracy >= 80 ? 1 : 0;
    this._showStars(stars, stats.accuracy, streak);
  },

  // ---- Game Completion ----
  celebrateGame(score, isHighscore, maxCombo) {
    this._updateStreak();

    if (isHighscore) this._earn('highscore');
    if (maxCombo >= 30) this._earn('combo_master');

    this._showGameOverlay(score, isHighscore, maxCombo);
  },

  // ---- Poem Actions ----
  onPoemSaved() {
    this._earn('poem_saved');
  },

  onPoemPrinted() {
    this._earn('poem_printed');
  },

  // ---- Achievement System ----
  _earn(id) {
    if (this._data.earned.includes(id)) return false;
    this._data.earned.push(id);
    this._save();
    this._showBadge(id);
    return true;
  },

  getAchievements() {
    return this._achievements.filter(a => this._data.earned.includes(a.id));
  },

  getAllAchievements() {
    return this._achievements.map(a => ({
      ...a,
      earned: this._data.earned.includes(a.id)
    }));
  },

  isEarned(id) {
    return this._data.earned.includes(id);
  },

  // ---- Visual Effects ----

  // Sternen-Bewertung nach Genauigkeit
  _showStars(count, accuracy, streak) {
    const overlay = this._createOverlay();
    overlay.innerHTML = `
      <div class="celebration-content">
        <div class="celebration-stars">${'⭐'.repeat(count)}</div>
        <div class="celebration-title">Lektion geschafft!</div>
        <div class="celebration-stats">
          ${accuracy}% Genauigkeit &middot; ${streak > 1 ? 'Tag ' + streak + ' in Folge!' : 'Weiter so!'}
        </div>
      </div>
    `;

    // Sterne animieren
    const starsEl = overlay.querySelector('.celebration-stars');
    if (count > 0) {
      starsEl.querySelectorAll('*').forEach((s, i) => {
        s.style.animationDelay = (i * 0.2) + 's';
      });
    } else {
      starsEl.innerHTML = '💪';
    }

    // Konfetti-Regen
    this._spawnConfetti(overlay, 40);

    // Auto-close
    setTimeout(() => overlay.classList.add('fade-out'), 2200);
    setTimeout(() => overlay.remove(), 2600);
  },

  // Spiel-Ergebnis-Overlay
  _showGameOverlay(score, isHighscore, maxCombo) {
    const overlay = this._createOverlay();
    const badge = isHighscore ? '<div class="celebration-badge">🏆 NEUER HIGHSCORE!</div>' : '';
    const comboBadge = maxCombo >= 30 ? '<div class="celebration-badge">🎯 ' + maxCombo + 'er Kombot!</div>' : '';

    overlay.innerHTML = `
      <div class="celebration-content">
        <div class="celebration-stars">🎮</div>
        <div class="celebration-title">Spiel vorbei!</div>
        <div class="celebration-score">${score} Punkte</div>
        ${badge}
        ${comboBadge}
      </div>
    `;

    if (isHighscore) this._spawnConfetti(overlay, 60);

    setTimeout(() => overlay.classList.add('fade-out'), 2500);
    setTimeout(() => overlay.remove(), 2900);
  },

  // Achievement-Badge Popup
  _showBadge(id) {
    const ach = this._achievements.find(a => a.id === id);
    if (!ach) return;

    const badge = document.createElement('div');
    badge.className = 'achievement-popup';
    badge.innerHTML = `
      <span class="ach-icon">${ach.icon}</span>
      <div class="ach-text">
        <strong>${ach.title}</strong>
        <span>${ach.desc}</span>
      </div>
    `;
    document.body.appendChild(badge);

    // Einfliegen von rechts unten
    requestAnimationFrame(() => badge.classList.add('show'));

    // Auto-remove
    setTimeout(() => {
      badge.classList.remove('show');
      setTimeout(() => badge.remove(), 500);
    }, 3500);
  },

  // Konfetti/Sterne-Partikel
  _spawnConfetti(container, count) {
    const emojis = ['⭐', '🌟', '✨', '💫', '🎉', '🎊', '💥', '🔥', '🍬', '🧁', '💎', '🌈', '⚡', '👏', '🥇'];
    const rect = container.getBoundingClientRect();

    for (let i = 0; i < count; i++) {
      const p = document.createElement('span');
      p.className = 'confetti-piece';
      p.textContent = emojis[Math.floor(Math.random() * emojis.length)];
      p.style.left = (20 + Math.random() * 60) + '%';
      p.style.top = (10 + Math.random() * 30) + '%';
      p.style.animationDuration = (1.2 + Math.random() * 1.8) + 's';
      p.style.animationDelay = (Math.random() * 0.6) + 's';
      p.style.fontSize = (1 + Math.random() * 2) + 'rem';
      container.appendChild(p);
    }
  },

  _createOverlay() {
    const existing = document.querySelector('.celebration-overlay');
    if (existing) existing.remove();

    const overlay = document.createElement('div');
    overlay.className = 'celebration-overlay';
    document.body.appendChild(overlay);
    return overlay;
  }
};
