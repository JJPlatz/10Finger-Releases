/* ============================================================
   app.js – Haupt-Controller: Tabs, Modi, Tastatur-Events
   ============================================================ */

const App = {
  _currentTab: 'lernen',
  _lernEngine: null,
  _freiEngine: null,
  _freiRunning: false,
  _freiKeystrokes: 0,
  _freiTimer: null,
  _freiStartTime: 0,
  _lernLoadedMd: null, // { title, text } from loaded MD file

  init() {
    // Auto-Fullscreen beim ersten Klick/Tastendruck
    const goFullscreen = () => {
      document.documentElement.requestFullscreen().catch(() => {});
    };
    const tryFullscreen = () => {
      goFullscreen();
      document.removeEventListener('click', tryFullscreen);
      document.removeEventListener('keydown', tryFullscreen);
    };
    document.addEventListener('click', tryFullscreen);
    document.addEventListener('keydown', tryFullscreen);
    // Auch direkt versuchen (manche Browser erlauben es ohne Geste)
    goFullscreen();

    // Initialize settings and rewards
    Settings.init();
    Rewards.init();

    // Initialize keyboard
    Keyboard.init('keyboardContainer', 'fingerLegend', 'handsOverlay', 'hintFingerName', 'hintFingerColor');

    // Init sub-modules
    this._initLernModus();
    this._initSpielModus();
    this._initGedichtModus();
    this._initFreiModus();
    this._initTabs();
    this._initGlobalKeyboard();
  },

  // ---- Tab Navigation ----
  _initTabs() {
    const buttons = document.querySelectorAll('.tab-btn');
    buttons.forEach(btn => {
      btn.addEventListener('click', () => {
        const tab = btn.dataset.tab;
        this._switchTab(tab);
      });
    });
  },

  _switchTab(tab) {
    this._currentTab = tab;

    // Blur active element so keyboard events reach the handler
    if (document.activeElement) document.activeElement.blur();

    // Update buttons
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelector(`.tab-btn[data-tab="${tab}"]`).classList.add('active');

    // Update panels
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    document.getElementById(`panel-${tab}`).classList.add('active');

    // Auto-save poem when leaving gedicht tab
    if (tab !== 'gedicht') {
      PoemEditor.autoSave();
    }

    // Clear keyboard highlights when switching
    Keyboard.clearHighlights();

    // Stop game timer when leaving spiel tab
    if (tab !== 'spiel' && GameMode.running) {
      GameMode.destroy();
    }

    // Focus handling
    if (tab === 'lernen') {
      this._focusTypingArea();
    } else if (tab === 'spiel') {
      this._focusTypingArea();
    }
  },

  _focusTypingArea() {
    // Ensure keyboard events are captured
    document.body.focus();
  },

  // ---- Global Keyboard Handler ----
  _initGlobalKeyboard() {
    document.addEventListener('keydown', (e) => {
      const tab = this._currentTab;

      // Ignore if user is typing in poem editor
      if (tab === 'gedicht') return;
      // Ignore if focus is on an input/select/button (unless disabled)
      if ((e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT' ||
          e.target.tagName === 'BUTTON' || e.target.tagName === 'TEXTAREA' ||
          e.target.isContentEditable) && !e.target.disabled) return;

      // Ignore modifier-only keypresses
      if (e.key === 'Shift' || e.key === 'Control' || e.key === 'Alt' ||
          e.key === 'AltGraph' || e.key === 'Meta' || e.key === 'CapsLock' ||
          e.key === 'Tab' || e.key === 'Escape' || e.key.startsWith('Arrow') ||
          e.key === 'Home' || e.key === 'End' || e.key === 'PageUp' ||
          e.key === 'PageDown' || e.key === 'Delete' || e.key === 'Insert') {
        // Allow Tab in non-typing contexts
        return;
      }

      // Prevent default browser behavior (like typing in page)
      if (tab === 'lernen' || tab === 'frei') {
        e.preventDefault();
      }

      // Get the actual character
      let key = e.key;
      if (key === 'Enter') key = '\n';
      if (key === 'Backspace') return; // ignore backspace

      if (key.length === 1) {
        this._handleTypingKey(key, tab);
      }
    });
  },

  _handleTypingKey(key, tab) {
    if (tab === 'spiel') {
      GameMode.handleKey(key);
      const expected = GameMode.engine ? GameMode.engine.text[GameMode.engine.position] : null;
      if (expected) Keyboard.highlightKey(expected);
      return;
    }

    if (tab === 'frei') {
      // Free mode: just count keystrokes, no target text
      if (!this._freiRunning) return;
      this._freiKeystrokes++;
      // Highlight the pressed key
      Keyboard.highlightKey(key);
      setTimeout(() => Keyboard.clearHighlights(), 400);
      // Update display with typed text
      const display = document.getElementById('textDisplayFrei');
      display.textContent += key;
      display.scrollTop = display.scrollHeight;
      return;
    }

    // Lern-Modus
    const engine = this._lernEngine;
    if (!engine || engine.done) return;

    const result = engine.handleKey(key);
    if (!result) return;

    if (result.correct) {
      const nextChar = engine.text[engine.position];
      if (nextChar) {
        Keyboard.highlightKey(nextChar);
      } else {
        Keyboard.clearHighlights();
      }
    } else {
      Keyboard.showError(key);
    }
  },

  // ---- Lern-Modus ----
  _initLernModus() {
    const display = document.getElementById('textDisplayLernen');
    this._lernEngine = new TypingEngine(display,
      (stats) => this._updateLernStats(stats),
      (stats) => this._onLernComplete(stats)
    );

    // Fill lesson dropdown
    const select = document.getElementById('lessonSelect');
    LESSONS.forEach((l, i) => {
      const opt = document.createElement('option');
      opt.value = i;
      opt.textContent = `${l.id}. ${l.title}`;
      select.appendChild(opt);
    });

    // Also add loaded MD file if present
    select.addEventListener('change', () => {
      select.blur();
      const idx = parseInt(select.value);
      if (idx >= 0 && idx < LESSONS.length) {
        this._loadLesson(idx);
        this._lernLoadedMd = null;
      } else if (this._lernLoadedMd) {
        // MD file slot
        this._lernEngine.loadText(this._lernLoadedMd.text);
        this._updateLernStatsDisplay(0, 0, 0, 100, 0);
      }
    });

    // Restart button
    document.getElementById('btnRestartLesson').addEventListener('click', () => {
      const idx = parseInt(select.value);
      if (idx >= 0 && idx < LESSONS.length) {
        this._loadLesson(idx);
      }
    });

    // MD file loader
    this._setupMdLoader(select);

    // Load first lesson by default
    this._loadLesson(0);
  },

  _loadLesson(idx) {
    const lesson = LESSONS[idx];
    this._lernEngine.loadText(lesson.text);
    this._lernEngine.startBlink();
    this._updateLernStatsDisplay(0, 0, 0, 100, 0);
    document.getElementById('timeLernen').textContent = '00:00';
    // Highlight first expected char
    const firstChar = lesson.text[0];
    if (firstChar) Keyboard.highlightKey(firstChar);
  },

  _setupMdLoader(select) {
    // Create file input
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = '.md,.txt';
    fileInput.style.display = 'none';
    document.body.appendChild(fileInput);

    // Create load button
    const loadBtn = document.createElement('button');
    loadBtn.id = 'btnLoadMd';
    loadBtn.className = 'btn btn-sm';
    loadBtn.textContent = '📂 Datei laden';
    loadBtn.title = 'MD-Datei von der Lehrkraft laden';
    const selector = document.querySelector('.lesson-selector');
    selector.appendChild(loadBtn);

    loadBtn.addEventListener('click', () => fileInput.click());

    fileInput.addEventListener('change', () => {
      const file = fileInput.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (e) => {
        const content = e.target.result;
        const parsed = this._parseMd(content);
        this._lernLoadedMd = parsed;

        // Add to dropdown
        // Remove previous MD entry if exists
        const existingOpt = select.querySelector('option[data-md]');
        if (existingOpt) existingOpt.remove();

        const opt = document.createElement('option');
        opt.value = 'md';
        opt.textContent = '📄 ' + parsed.title;
        opt.dataset.md = 'true';
        opt.selected = true;
        select.appendChild(opt);

        this._lernEngine.loadText(parsed.text);
        this._updateLernStatsDisplay(0, 0, 0, 100, 0);
        document.getElementById('timeLernen').textContent = '00:00';
        const firstChar = parsed.text[0];
        if (firstChar) Keyboard.highlightKey(firstChar);

        // Flash load button
        loadBtn.textContent = '✓ Geladen';
        setTimeout(() => { loadBtn.textContent = '📂 Datei laden'; }, 1500);
      };
      reader.readAsText(file);
    });
  },

  _parseMd(content) {
    const lines = content.trim().split('\n');
    let title = 'Eigene Übung';
    let textStart = 0;

    // First heading becomes title
    if (lines[0].startsWith('# ')) {
      title = lines[0].substring(2).trim();
      textStart = 1;
    } else if (lines[0].startsWith('#')) {
      title = lines[0].substring(1).trim();
      textStart = 1;
    }

    // Skip empty lines after title
    while (textStart < lines.length && lines[textStart].trim() === '') {
      textStart++;
    }

    const text = lines.slice(textStart).join('\n');
    return { title, text: text || content };
  },

  _updateLernStats(stats) {
    this._updateLernStatsDisplay(stats.cpm, stats.wpm, stats.errors, stats.accuracy, stats.duration);
  },

  _updateLernStatsDisplay(cpm, wpm, errors, accuracy, duration) {
    document.getElementById('cpmLernen').textContent = cpm;
    document.getElementById('wpmLernen').textContent = wpm;
    document.getElementById('errLernen').textContent = errors;
    document.getElementById('accLernen').textContent = accuracy + '%';
    if (duration !== undefined) {
      const min = Math.floor(duration / 60);
      const sec = duration % 60;
      document.getElementById('timeLernen').textContent =
        String(min).padStart(2, '0') + ':' + String(sec).padStart(2, '0');
    }
  },

  _onLernComplete(stats) {
    const select = document.getElementById('lessonSelect');
    const idx = parseInt(select.value);
    let lessonTitle = 'Unbekannt';

    if (idx >= 0 && idx < LESSONS.length) {
      lessonTitle = LESSONS[idx].title;
    } else if (this._lernLoadedMd) {
      lessonTitle = this._lernLoadedMd.title;
    }

    Stats.saveResult(idx >= 0 ? idx : -1, lessonTitle, stats);
    Keyboard.clearHighlights();

    // Show completion message
    const display = document.getElementById('textDisplayLernen');
    const msg = `✓ Geschafft! ${stats.cpm} Anschläge/min | ${stats.accuracy}% Genauigkeit | ${stats.errors} Fehler`;
    display.innerHTML = `<div style="color:#40c057;font-size:1.3rem;text-align:center;padding:20px;">${msg}</div>`;

    // Celebration!
    Rewards.celebrateLesson(stats);
  },

  // ---- Spiel-Modus ----
  _initSpielModus() {
    GameMode.init('textDisplaySpiel');
  },

  // ---- Gedicht-Modus ----
  _initGedichtModus() {
    PoemEditor.init('poemEditor');
  },

  // ---- Freier Modus ----
  _initFreiModus() {
    document.getElementById('btnStartFree').addEventListener('click', () => {
      if (this._freiRunning) {
        // Stop
        this._freiRunning = false;
        if (this._freiTimer) clearInterval(this._freiTimer);
        const elapsed = (Date.now() - this._freiStartTime) / 60000;
        const cpm = elapsed > 0 ? Math.round(this._freiKeystrokes / elapsed) : 0;
        const wpm = Math.round(cpm / 5);
        document.getElementById('btnStartFree').textContent = 'Training starten';
        Keyboard.clearHighlights();
        const display = document.getElementById('textDisplayFrei');
        display.innerHTML =
          `<div style="color:#a78bfa;font-size:1.2rem;text-align:center;padding:20px;">` +
          `Training beendet: ${cpm} Anschläge/min | ${Math.round(elapsed * 60)}s Dauer` +
          `</div>`;
      } else {
        this._freiRunning = true;
        this._freiKeystrokes = 0;
        this._freiStartTime = Date.now();
        document.getElementById('textDisplayFrei').textContent = '';
        document.getElementById('btnStartFree').textContent = 'Training beenden';
        document.getElementById('timeFrei').textContent = '00:00';
        document.getElementById('cpmFrei').textContent = '0';
        document.getElementById('wpmFrei').textContent = '0';
        document.getElementById('accFrei').textContent = '-';
        document.getElementById('errFrei').textContent = '0';
        this._freiTimer = setInterval(() => this._tickFrei(), 1000);
      }
    });

    document.getElementById('btnResetFree').addEventListener('click', () => {
      this._freiRunning = false;
      this._freiKeystrokes = 0;
      if (this._freiTimer) clearInterval(this._freiTimer);
      document.getElementById('textDisplayFrei').innerHTML =
        '<p>Gib einen beliebigen Text ein. Drücke <strong>Training starten</strong>, um mit der Zeiterfassung zu beginnen.</p>';
      document.getElementById('btnStartFree').textContent = 'Training starten';
      document.getElementById('timeFrei').textContent = '00:00';
      document.getElementById('cpmFrei').textContent = '0';
      document.getElementById('wpmFrei').textContent = '0';
      document.getElementById('accFrei').textContent = '-';
      document.getElementById('errFrei').textContent = '0';
      Keyboard.clearHighlights();
    });
  },

  _tickFrei() {
    if (!this._freiRunning) return;
    const elapsed = Math.max(0.01, (Date.now() - this._freiStartTime) / 60000);
    const cpm = Math.round(this._freiKeystrokes / elapsed);
    const wpm = Math.round(cpm / 5);
    const min = Math.floor(elapsed);
    const sec = Math.round((elapsed - min) * 60);
    document.getElementById('cpmFrei').textContent = cpm;
    document.getElementById('wpmFrei').textContent = wpm;
    document.getElementById('timeFrei').textContent =
      String(min).padStart(2, '0') + ':' + String(sec).padStart(2, '0');
    document.getElementById('errFrei').textContent = '0';
  },
};

// ---- Boot ----
document.addEventListener('DOMContentLoaded', () => {
  TrialManager.init();

  if (TrialManager.getStatus() === 'expired') {
    TrialManager._showLicenseOverlay();
    return;
  }

  App.init();

  if (TrialManager.getStatus() === 'trial') {
    TrialManager._showTrialBanner();
  }
});
