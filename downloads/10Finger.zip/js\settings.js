/* ============================================================
   settings.js – Einstellungen: Schriftart, Fehler-Modus,
                 Hilfestellungen-Toggles, Vollbild
   ============================================================ */

const Settings = {
  _key: '10Finger_settings',
  _passcodeKey: '10Finger_passcode',
  _data: null,
  _panel: null,
  _gearBtn: null,
  _unlocked: false,

  // Defaults
  _defaults: {
    font: 'consolas',        // 'consolas' | 'times'
    errorMode: 'strict',     // 'strict' | 'mild'
    keyColors: true,
    showHands: true,
    fingerHint: true
  },

  init() {
    this._load();
    this._setupUI();
    this._applyAll();
  },

  _load() {
    try {
      const raw = localStorage.getItem(this._key);
      this._data = raw ? Object.assign({}, this._defaults, JSON.parse(raw)) : Object.assign({}, this._defaults);
    } catch {
      this._data = Object.assign({}, this._defaults);
    }
  },

  _save() {
    try {
      localStorage.setItem(this._key, JSON.stringify(this._data));
    } catch { /* ignore */ }
  },

  get(name) {
    return this._data[name] !== undefined ? this._data[name] : this._defaults[name];
  },

  set(name, value) {
    if (this._data[name] !== value) {
      this._data[name] = value;
      this._save();
      this._apply(name);
    }
  },

  // ---- UI Setup ----
  _setupUI() {
    this._panel = document.getElementById('settingsPanel');
    this._gearBtn = document.getElementById('btnSettings');

    // Gear button: show passcode overlay if locked, toggle panel if unlocked
    this._gearBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      if (this._unlocked) {
        this._panel.classList.toggle('open');
        if (!this._panel.classList.contains('open')) {
          this._unlocked = false; // re-lock when panel closes via gear click
        }
      } else {
        this._showPasscodeOverlay();
      }
    });

    // Click outside closes panel (and re-locks)
    document.addEventListener('click', (e) => {
      if (this._panel.classList.contains('open') &&
          !this._panel.contains(e.target) &&
          e.target !== this._gearBtn) {
        this._panel.classList.remove('open');
        this._unlocked = false;
      }
    });

    // Close with Escape (and re-lock)
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        if (this._panel.classList.contains('open')) {
          this._panel.classList.remove('open');
          this._unlocked = false;
        }
        if (document.getElementById('passcodeOverlay').classList.contains('open')) {
          this._hidePasscodeOverlay();
        }
      }
    });

    // Schriftart
    document.getElementById('settingFont').addEventListener('change', (e) => {
      this.set('font', e.target.value);
    });

    // Fehler-Modus
    document.getElementById('settingErrorMode').addEventListener('change', (e) => {
      this.set('errorMode', e.target.value);
    });

    // Tastatur-Farben
    document.getElementById('settingKeyColors').addEventListener('change', (e) => {
      this.set('keyColors', e.target.checked);
    });

    // Hände
    document.getElementById('settingShowHands').addEventListener('change', (e) => {
      this.set('showHands', e.target.checked);
    });

    // Finger-Hinweis
    document.getElementById('settingFingerHint').addEventListener('change', (e) => {
      this.set('fingerHint', e.target.checked);
    });

    // Vollbild
    document.getElementById('btnFullscreen').addEventListener('click', () => {
      this._toggleFullscreen();
    });

    // Alles zurücksetzen
    document.getElementById('btnResetAll').addEventListener('click', () => {
      this._resetAll();
    });

    // Passcode ändern
    document.getElementById('btnChangePasscode').addEventListener('click', () => {
      this._changePasscode();
    });

    // Passcode-Overlay: Enter-Taste prüft den Code
    const overlay = document.getElementById('passcodeOverlay');
    const passInput = document.getElementById('passcodeInput');
    passInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') this._checkPasscode();
    });
    // Nur Ziffern erlauben
    passInput.addEventListener('input', () => {
      passInput.value = passInput.value.replace(/[^0-9]/g, '');
    });
    // Klick auf Overlay-Hintergrund schließt
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) this._hidePasscodeOverlay();
    });

    // Update UI to match loaded settings
    this._updateControls();
  },

  _updateControls() {
    document.getElementById('settingFont').value = this._data.font;
    document.getElementById('settingErrorMode').value = this._data.errorMode;
    document.getElementById('settingKeyColors').checked = this._data.keyColors;
    document.getElementById('settingShowHands').checked = this._data.showHands;
    document.getElementById('settingFingerHint').checked = this._data.fingerHint;
  },

  // ---- Apply Settings ----
  _applyAll() {
    for (const key of Object.keys(this._defaults)) {
      this._apply(key);
    }
  },

  _apply(key) {
    switch (key) {
      case 'font':
        this._applyFont();
        break;
      case 'errorMode':
        // Stored for TypingEngine to read
        break;
      case 'keyColors':
        this._applyKeyColors();
        break;
      case 'showHands':
        this._applyShowHands();
        break;
      case 'fingerHint':
        this._applyFingerHint();
        break;
    }
  },

  _applyFont() {
    const fontFamily = this._data.font === 'times'
      ? "'Times New Roman', Georgia, serif"
      : "'Cascadia Code', 'Fira Code', 'Consolas', monospace";
    document.documentElement.style.setProperty('--typing-font', fontFamily);

    // Update all text-display elements
    document.querySelectorAll('.text-display').forEach(el => {
      el.style.fontFamily = fontFamily;
    });
    document.querySelectorAll('.typed-text').forEach(el => {
      el.style.fontFamily = fontFamily;
    });
  },

  _applyKeyColors() {
    const kb = document.getElementById('keyboardContainer');
    if (!kb) return;
    if (this._data.keyColors) {
      kb.classList.remove('no-colors');
    } else {
      kb.classList.add('no-colors');
    }
  },

  _applyShowHands() {
    const hands = document.getElementById('handsOverlay');
    if (!hands) return;
    hands.style.display = this._data.showHands ? '' : 'none';
  },

  _applyFingerHint() {
    const hint = document.getElementById('fingerHint');
    if (!hint) return;
    hint.style.display = this._data.fingerHint ? '' : 'none';
  },

  // ---- Passcode ----
  _getPasscode() {
    try {
      return localStorage.getItem(this._passcodeKey) || '1234';
    } catch {
      return '1234';
    }
  },

  _showPasscodeOverlay() {
    const overlay = document.getElementById('passcodeOverlay');
    const input = document.getElementById('passcodeInput');
    const error = document.getElementById('passcodeError');
    const box = document.getElementById('passcodeBox');
    overlay.classList.add('open');
    box.classList.remove('shake');
    error.classList.remove('show');
    input.value = '';
    setTimeout(() => input.focus(), 100);
  },

  _hidePasscodeOverlay() {
    document.getElementById('passcodeOverlay').classList.remove('open');
  },

  _checkPasscode() {
    const input = document.getElementById('passcodeInput');
    const code = input.value;
    const stored = this._getPasscode();

    if (code === stored) {
      this._unlocked = true;
      this._hidePasscodeOverlay();
      this._panel.classList.add('open');
    } else {
      document.getElementById('passcodeError').classList.add('show');
      document.getElementById('passcodeBox').classList.add('shake');
      input.value = '';
      input.focus();
      setTimeout(() => {
        document.getElementById('passcodeError').classList.remove('show');
        document.getElementById('passcodeBox').classList.remove('shake');
      }, 1200);
    }
  },

  _changePasscode() {
    const neu = document.getElementById('settingNewPasscode').value;
    const conf = document.getElementById('settingConfirmPasscode').value;
    const hint = document.getElementById('passcodeChangeHint');

    if (!neu || neu.length !== 4 || !/^\d{4}$/.test(neu)) {
      hint.textContent = 'Code muss aus 4 Ziffern bestehen';
      hint.className = 'passcode-change-hint error';
      return;
    }
    if (neu !== conf) {
      hint.textContent = 'Codes stimmen nicht überein';
      hint.className = 'passcode-change-hint error';
      return;
    }
    try {
      localStorage.setItem(this._passcodeKey, neu);
      hint.textContent = '✓ Code geändert';
      hint.className = 'passcode-change-hint success';
      document.getElementById('settingNewPasscode').value = '';
      document.getElementById('settingConfirmPasscode').value = '';
      setTimeout(() => { hint.textContent = ''; hint.className = 'passcode-change-hint'; }, 2000);
    } catch {
      hint.textContent = 'Fehler beim Speichern';
      hint.className = 'passcode-change-hint error';
    }
  },

  // ---- Reset ----
  _resetAll() {
    if (!confirm('Wirklich alle Daten löschen?\n\nHighscore, Statistik, Gedicht und Erfolge werden zurückgesetzt. Das kann nicht rückgängig gemacht werden.')) return;

    // Lizenz vor dem Löschen sichern
    const savedLicense = localStorage.getItem('10Finger_license');

    // Alle 10Finger-Schlüssel aus localStorage entfernen
    const keys = [];
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key.startsWith('10Finger_')) keys.push(key);
    }
    keys.forEach(k => localStorage.removeItem(k));

    // Passcode auf Default zurücksetzen
    localStorage.setItem(this._passcodeKey, '1234');

    // Lizenz wiederherstellen
    if (savedLicense) {
      localStorage.setItem('10Finger_license', savedLicense);
    }

    // Einstellungen neu laden (mit Defaults)
    this._data = Object.assign({}, this._defaults);
    this._save();
    this._updateControls();
    this._applyAll();

    // Visuelles Feedback
    const btn = document.getElementById('btnResetAll');
    btn.textContent = '✓ Gelöscht';
    btn.style.background = '#40c057';
    setTimeout(() => {
      btn.textContent = 'Alle Daten löschen';
      btn.style.background = '';
    }, 2000);

    // Panel schließen
    this._panel.classList.remove('open');
  },

  // ---- Fullscreen ----
  _toggleFullscreen() {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
    } else {
      document.exitFullscreen();
    }
  }
};
