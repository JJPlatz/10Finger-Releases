/* ============================================================
   stats.js – Lernstatistik (localStorage)
   ============================================================ */

const Stats = {
  _key: '10Finger_stats',
  _data: null,

  _load() {
    if (this._data) return this._data;
    try {
      const raw = localStorage.getItem(this._key);
      this._data = raw ? JSON.parse(raw) : { results: [], highscore: 0 };
    } catch {
      this._data = { results: [], highscore: 0 };
    }
    return this._data;
  },

  _save() {
    try {
      localStorage.setItem(this._key, JSON.stringify(this._data));
    } catch { /* localStorage voll */ }
  },

  saveResult(lessonId, lessonTitle, stats) {
    const d = this._load();
    d.results.push({
      date: new Date().toISOString(),
      lessonId,
      lessonTitle,
      cpm: stats.cpm,
      wpm: stats.wpm,
      accuracy: stats.accuracy,
      errors: stats.errors,
      duration: stats.duration
    });
    // Keep max 200 entries
    if (d.results.length > 200) d.results = d.results.slice(-200);
    this._save();
  },

  saveGameHighscore(score) {
    const d = this._load();
    if (score > d.highscore) {
      d.highscore = score;
      this._save();
      return true; // new highscore
    }
    return false;
  },

  getHighscore() {
    return this._load().highscore || 0;
  },

  getHistory(lessonId) {
    const d = this._load();
    if (lessonId !== undefined) {
      return d.results.filter(r => r.lessonId === lessonId);
    }
    return d.results;
  },

  getRecentResults(count) {
    const d = this._load();
    return d.results.slice(-count || -5);
  },

  clearAll() {
    this._data = { results: [], highscore: 0 };
    this._save();
  }
};
