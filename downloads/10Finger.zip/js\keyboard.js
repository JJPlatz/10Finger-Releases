/* ============================================================
   keyboard.js – Tastatur-Rendering, Highlight, Legende,
                 durchscheinende Hände mit Finger-Anzeige
   ============================================================ */

const Keyboard = {
  _container: null,
  _legendContainer: null,
  _handsContainer: null,
  _hintName: null,
  _hintColor: null,
  _keyElements: {},
  _handFingers: {},    // fingerIndex → SVG element (for highlight)

  init(containerId, legendId, handsId, hintNameId, hintColorId) {
    this._container = document.getElementById(containerId);
    this._legendContainer = document.getElementById(legendId);
    this._handsContainer = document.getElementById(handsId);
    this._hintName = document.getElementById(hintNameId);
    this._hintColor = document.getElementById(hintColorId);
    this._renderLegend();
    this._renderHands();
    this._renderKeyboard();
  },

  _renderLegend() {
    this._legendContainer.innerHTML = '';
    for (const f of FINGERS) {
      const item = document.createElement('span');
      item.className = 'legend-item';
      item.innerHTML = `<span class="legend-dot" style="background:${f.color}"></span>${f.name}`;
      this._legendContainer.appendChild(item);
    }
  },

  // ---- Durchscheinende Hände ----
  _renderHands() {
    this._handsContainer.innerHTML = '';
    this._handFingers = {};

    const svgNS = 'http://www.w3.org/2000/svg';

    // === Linke Hand ===
    const svgL = document.createElementNS(svgNS, 'svg');
    svgL.setAttribute('viewBox', '0 0 200 160');
    svgL.setAttribute('class', 'hand-svg hand-left');
    svgL.innerHTML = this._buildHandSVG('left');
    this._handsContainer.appendChild(svgL);

    // Rechte Hand
    const svgR = document.createElementNS(svgNS, 'svg');
    svgR.setAttribute('viewBox', '0 0 200 160');
    svgR.setAttribute('class', 'hand-svg hand-right');
    svgR.innerHTML = this._buildHandSVG('right');
    this._handsContainer.appendChild(svgR);

    // Collect finger elements by finger index
    const allFingers = this._handsContainer.querySelectorAll('[data-finger]');
    allFingers.forEach(el => {
      const idx = parseInt(el.dataset.finger);
      if (!this._handFingers[idx]) this._handFingers[idx] = [];
      this._handFingers[idx].push(el);
    });
  },

  _buildHandSVG(side) {
    const fingers = side === 'left'
      ? [
          { id: 0, label: 'pinky',  x1: 58, y1: 100, x2: 68, y2: 14, color: FINGERS[0].color },
          { id: 1, label: 'ring',   x1: 72, y1: 94,  x2: 82, y2: 10, color: FINGERS[1].color },
          { id: 2, label: 'middle', x1: 86, y1: 90,  x2: 96, y2: 6,  color: FINGERS[2].color },
          { id: 3, label: 'index',  x1: 100, y1: 94, x2: 110, y2: 12, color: FINGERS[3].color },
          { id: 8, label: 'thumb',  x1: 92, y1: 134, x2: 115, y2: 128, color: FINGERS[8].color },
        ]
      : [
          { id: 4, label: 'index',  x1: 100, y1: 94, x2: 90, y2: 12, color: FINGERS[4].color },
          { id: 5, label: 'middle', x1: 114, y1: 90, x2: 104, y2: 6,  color: FINGERS[5].color },
          { id: 6, label: 'ring',   x1: 128, y1: 94,  x2: 118, y2: 10, color: FINGERS[6].color },
          { id: 7, label: 'pinky',  x1: 142, y1: 100, x2: 132, y2: 14, color: FINGERS[7].color },
          { id: 8, label: 'thumb',  x1: 108, y1: 134, x2: 85, y2: 128, color: FINGERS[8].color },
        ];

    let html = '';

    // Palm (flesh-toned, semi-transparent background)
    const palmCx = side === 'left' ? 76 : 124;
    const palmCy = 110;
    html += `<ellipse cx="${palmCx}" cy="${palmCy}" rx="38" ry="44"
              fill="#e8c8a0" fill-opacity="0.25" stroke="#c8a888" stroke-width="1.5" stroke-opacity="0.3"/>`;

    // Wrist
    const wristX = side === 'left' ? 76 : 124;
    const wristDir = side === 'left' ? -18 : 18;
    html += `<rect x="${wristX + wristDir - 14}" y="138" width="28" height="22" rx="8"
              fill="#e8c8a0" fill-opacity="0.2" stroke="#c8a888" stroke-width="1" stroke-opacity="0.25"/>`;

    // Fingers
    for (const f of fingers) {
      html += `<line x1="${f.x1}" y1="${f.y1}" x2="${f.x2}" y2="${f.y2}"
                stroke="${f.color}" stroke-width="12" stroke-linecap="round"
                stroke-opacity="0.35" class="hand-finger"
                data-finger="${f.id}" data-hand="${side}"/>`;

      // Fingertip dot
      html += `<circle cx="${f.x2}" cy="${f.y2}" r="7"
                fill="${f.color}" fill-opacity="0.35" class="hand-fingertip"
                data-finger="${f.id}" data-hand="${side}"/>`;
    }

    // Home-row position markers (tiny dots on ASDF / JKLÖ)
    const homeDots = side === 'left'
      ? [ { x: 66, y: 22, label: 'A' }, { x: 80, y: 18, label: 'S' },
          { x: 94, y: 14, label: 'D' }, { x: 108, y: 20, label: 'F' } ]
      : [ { x: 92, y: 20, label: 'J' }, { x: 106, y: 14, label: 'K' },
          { x: 120, y: 18, label: 'L' }, { x: 134, y: 22, label: 'Ö' } ];

    for (const d of homeDots) {
      html += `<circle cx="${d.x}" cy="${d.y}" r="4"
                fill="white" fill-opacity="0.5" stroke="rgba(255,255,255,0.6)" stroke-width="1"/>`;
    }

    return html;
  },

  // Aktiviere einen bestimmten Finger in den Händen
  activateHandFinger(fingerIndex) {
    // Reset all fingers
    const allFingers = this._handsContainer.querySelectorAll('.hand-finger, .hand-fingertip');
    allFingers.forEach(el => {
      el.setAttribute('stroke-opacity', el.classList.contains('hand-finger') ? '0.35' : '');
      el.setAttribute('fill-opacity', el.classList.contains('hand-fingertip') ? '0.35' : '');
      el.classList.remove('active');
    });

    // Activate matching finger
    if (fingerIndex !== undefined && fingerIndex >= 0 && fingerIndex <= 8) {
      const fingers = this._handsContainer.querySelectorAll(`[data-finger="${fingerIndex}"]`);
      fingers.forEach(el => {
        el.setAttribute('stroke-opacity', el.classList.contains('hand-finger') ? '0.95' : '');
        el.setAttribute('fill-opacity', el.classList.contains('hand-fingertip') ? '0.95' : '');
        el.classList.add('active');
      });
      // Also update finger hint
      if (fingerIndex < FINGERS.length) {
        this._hintName.textContent = FINGERS[fingerIndex].name;
        this._hintColor.style.background = FINGERS[fingerIndex].color;
        this._hintColor.style.display = 'inline-block';
      }
    } else {
      // Reset hint if no specific finger
      // (keep hint visible when just highlighting a key on keyboard)
    }
  },

  // ---- Keyboard ----
  _renderKeyboard() {
    this._container.innerHTML = '';
    this._keyElements = {};
    for (const row of KEYBOARD_ROWS) {
      const rowEl = document.createElement('div');
      rowEl.className = 'keyboard-row';
      for (const key of row) {
        const keyEl = document.createElement('div');
        let cls = 'key';
        if (key.width) cls += ' ' + key.width;
        if (key.finger >= 0 && key.finger <= 8) {
          cls += ' ' + FINGERS[key.finger].cssClass;
        }
        keyEl.className = cls;
        keyEl.textContent = key.label;

        const lookup = key.label.toLowerCase();
        if (lookup.length === 1) {
          this._keyElements[lookup] = keyEl;
          const upper = key.label.toUpperCase();
          this._keyElements[upper] = keyEl;
        }
        if (key.label === ' ' || key.label === '') {
          this._keyElements[' '] = keyEl;
        }
        this._keyElements[key.label] = keyEl;

        rowEl.appendChild(keyEl);
      }
      this._container.appendChild(rowEl);
    }
  },

  highlightKey(ch) {
    this.clearHighlights();
    const el = this._keyElements[ch] || this._keyElements[ch.toLowerCase()];
    if (el) {
      el.classList.add('highlight');
      const fid = getFingerForChar(ch);
      if (fid >= 0) {
        this.activateHandFinger(fid);
      }
    }
  },

  showError(ch) {
    const el = this._keyElements[ch] || this._keyElements[ch.toLowerCase()];
    if (el) {
      el.classList.add('highlight-error');
      setTimeout(() => el.classList.remove('highlight-error'), 300);
    }
    const fid = getFingerForChar(ch);
    if (fid >= 0) {
      this.activateHandFinger(fid);
      // Briefly pulse error
      const handFingers = this._handsContainer.querySelectorAll(`[data-finger="${fid}"]`);
      handFingers.forEach(el => {
        const origStroke = el.getAttribute('stroke');
        el.setAttribute('stroke', '#f87171');
        el.setAttribute('stroke-opacity', '1');
        setTimeout(() => {
          el.setAttribute('stroke', origStroke);
          el.setAttribute('stroke-opacity', '0.35');
        }, 400);
      });
    }
  },

  clearHighlights() {
    const all = this._container.querySelectorAll('.key.highlight, .key.highlight-error');
    for (const el of all) {
      el.classList.remove('highlight');
      el.classList.remove('highlight-error');
    }
    this.activateHandFinger(-1);
    this._hintName.textContent = '';
    this._hintColor.style.display = 'none';
  }
};
