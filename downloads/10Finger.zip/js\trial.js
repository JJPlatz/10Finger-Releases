/* ============================================================
   trial.js – Testversion & Lizenzschlüssel-Freischaltung
   ============================================================ */

const TrialManager = {
  _keyStart: '10Finger_trialStart',
  _keyLicense: '10Finger_license',
  TRIAL_DAYS: 28,

  init() {
    // Set trial start on first launch
    if (!localStorage.getItem(this._keyStart)) {
      localStorage.setItem(this._keyStart, new Date().toISOString().split('T')[0]);
    }

    // Validate stored license
    const lic = localStorage.getItem(this._keyLicense);
    if (lic && !this._isValidKey(lic)) {
      localStorage.removeItem(this._keyLicense);
    }
  },

  getStatus() {
    if (localStorage.getItem(this._keyLicense)) return 'licensed';
    if (this._getDaysLeft() > 0) return 'trial';
    return 'expired';
  },

  _getDaysLeft() {
    const start = localStorage.getItem(this._keyStart);
    if (!start) return 0;
    const elapsed = Math.floor((Date.now() - new Date(start).getTime()) / 86400000);
    return Math.max(0, this.TRIAL_DAYS - elapsed);
  },

  _getDaysUsed() {
    const start = localStorage.getItem(this._keyStart);
    if (!start) return 0;
    const elapsed = Math.floor((Date.now() - new Date(start).getTime()) / 86400000);
    return Math.min(this.TRIAL_DAYS, elapsed);
  },

  // ---- Key validation ----
  _computeChecksum(hexBlock) {
    const val = parseInt(hexBlock, 16);
    let cs = ((val * 0x5A3) + 0x1F4B) & 0xFFFF;
    cs ^= 0xA5C3;
    return cs.toString(16).toUpperCase().padStart(4, '0');
  },

  _isValidKey(key) {
    key = key.trim().toUpperCase();
    if (!/^10F-[0-9A-F]{4}-[0-9A-F]{4}$/.test(key)) return false;
    const parts = key.split('-');
    return this._computeChecksum(parts[1]) === parts[2];
  },

  activate(key) {
    if (this._isValidKey(key)) {
      localStorage.setItem(this._keyLicense, key.trim().toUpperCase());
      return true;
    }
    return false;
  },

  // ---- License overlay ----
  _showLicenseOverlay() {
    const overlay = document.getElementById('licenseOverlay');
    const box = document.getElementById('licenseBox');
    const input = document.getElementById('licenseInput');
    const error = document.getElementById('licenseError');

    overlay.classList.add('open');
    error.classList.remove('show');
    box.classList.remove('shake');
    input.value = '';

    // Prevent Escape / click-outside from closing
    const trapFocus = (e) => {
      if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); }
    };
    document.addEventListener('keydown', trapFocus, true);

    // Enter triggers activation
    const onEnter = (e) => {
      if (e.key === 'Enter') {
        const raw = input.value;
        if (this.activate(raw)) {
          overlay.classList.remove('open');
          document.removeEventListener('keydown', trapFocus, true);
          document.removeEventListener('keydown', onEnter);
          App.init();
          if (TrialManager.getStatus() === 'trial') {
            TrialManager._showTrialBanner();
          }
        } else {
          error.classList.add('show');
          box.classList.add('shake');
          input.value = '';
          setTimeout(() => {
            error.classList.remove('show');
            box.classList.remove('shake');
          }, 1200);
        }
      }
    };
    document.addEventListener('keydown', onEnter);

    // Auto-focus input
    setTimeout(() => input.focus(), 200);

    // Allow digit/letter entry in overlay
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Backspace' || e.key === 'Delete' || e.key === 'Tab' ||
          e.key === 'ArrowLeft' || e.key === 'ArrowRight' || e.key === 'Home' ||
          e.key === 'End' || e.key === 'Enter') return;
      const ch = e.key.toUpperCase();
      if (!/[0-9A-F\-]/.test(ch)) e.preventDefault();
    });
  },

  // ---- Trial banner ----
  _showTrialBanner() {
    const days = this._getDaysLeft();
    const banner = document.getElementById('trialBanner');
    const text = document.getElementById('trialBannerText');
    if (banner && text) {
      text.textContent = `Testversion – noch ${days} Tag${days !== 1 ? 'e' : ''} (Tag ${this._getDaysUsed()}/${this.TRIAL_DAYS})`;
      banner.classList.add('open');
    }
  }
};
