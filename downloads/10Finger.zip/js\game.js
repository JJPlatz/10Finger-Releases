/* ============================================================
   game.js – TypingEngine + Spiel-Modus
   ============================================================ */

// ---- Typing Engine (shared between modes) ----

class TypingEngine {
  constructor(displayEl, onUpdate, onComplete) {
    this._display = displayEl;
    this._onUpdate = onUpdate || (() => {});
    this._onComplete = onComplete || (() => {});
    this.reset();
  }

  reset() {
    this._text = '';
    this._position = 0;
    this._totalKeystrokes = 0;
    this._errors = 0;
    this._errorSet = new Set(); // positions with errors
    this._startTime = null;
    this._endTime = null;
    this._running = false;
    this._done = false;
    this.displayText('');
  }

  get errorMode() {
    return (typeof Settings !== 'undefined') ? Settings.get('errorMode') : 'strict';
  }

  loadText(text) {
    this.reset();
    this._text = text;
    this._render();
  }

  get text() { return this._text; }
  get position() { return this._position; }
  get running() { return this._running; }
  get done() { return this._done; }

  start() {
    this._running = true;
    this._startTime = Date.now();
  }

  handleKey(key) {
    if (this._done) return null;
    if (!this._running) this.start();

    this._totalKeystrokes++;

    const expected = this._text[this._position];
    if (!expected) {
      this._finish();
      return null;
    }

    const isCorrect = (key === expected);

    if (isCorrect) {
      this._position++;
      this._render();
      this._onUpdate(this.getStats());

      if (this._position >= this._text.length) {
        this._finish();
        this._onComplete(this.getStats());
      }

      return { correct: true, char: expected, position: this._position - 1, done: this._done };
    } else {
      this._errors++;
      this._errorSet.add(this._position);
      // Mild mode: advance anyway
      if (this.errorMode === 'mild') {
        this._position++;
      }
      this._render();
      this._onUpdate(this.getStats());

      // Check completion (for mild mode where we advanced despite error)
      if (this._position >= this._text.length) {
        this._finish();
        this._onComplete(this.getStats());
      }

      return { correct: false, char: key, expected, position: this._position - (this.errorMode === 'mild' ? 1 : 0), done: this._done };
    }
  }

  _finish() {
    this._done = true;
    this._running = false;
    this._endTime = Date.now();
  }

  getStats() {
    const now = this._done && this._endTime ? this._endTime : Date.now();
    const start = this._startTime || now;
    const elapsedMinutes = Math.max(0.01, (now - start) / 60000);
    const cpm = Math.round(this._position / elapsedMinutes);
    const words = this._position / 5;
    const wpm = Math.round(words / elapsedMinutes);
    const total = this._totalKeystrokes;
    const accuracy = total > 0 ? Math.round((this._position / total) * 100) : 100;

    return {
      position: this._position,
      total: this._text.length,
      cpm,
      wpm,
      accuracy,
      errors: this._errors,
      totalKeystrokes: total,
      duration: Math.round((now - start) / 1000),
      running: this._running,
      done: this._done
    };
  }

  _render() {
    let html = '';
    for (let i = 0; i < this._text.length; i++) {
      const ch = this._text[i];
      if (i < this._position) {
        const cls = this._errorSet.has(i) ? 'char-error' : 'char-correct';
        html += `<span class="${cls}">${this._escapeHtml(ch)}</span>`;
      } else if (i === this._position) {
        const errCls = this._errorSet.has(i) ? ' char-error' : '';
        html += `<span class="char-current${errCls}">${this._escapeHtml(ch)}</span>`;
      } else {
        html += this._escapeHtml(ch);
      }
    }
    this._display.innerHTML = html;

    // Scroll current char into view
    const cur = this._display.querySelector('.char-current');
    if (cur) cur.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  }

  displayText(html) {
    this._display.innerHTML = html;
  }

  _escapeHtml(s) {
    return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\n/g, '<br>');
  }

  // Blink animation for current character
  startBlink() {
    const cur = this._display.querySelector('.char-current');
    if (cur) cur.style.animation = 'blink-cursor 0.8s infinite';
  }
}

// ---- Game Mode Controller ----

const GameMode = {
  _engine: null,
  _timer: null,
  _timeLeft: 60,
  _score: 0,
  _combo: 0,
  _maxCombo: 0,
  _running: false,
  _texts: null,

  init(displayId) {
    const display = document.getElementById(displayId);
    this._engine = new TypingEngine(display,
      (stats) => this._onUpdate(stats),
      (stats) => this._onComplete(stats)
    );
    this._initTexts();
    this._setupUI();
  },

  _initTexts() {
    // Fun, cool texts for 11-14 year olds
    this._texts = [
      'Coole Sprüche sind die beste Medizin, wenn der Tag mal wieder nervt. Einfach weitermachen!\n',
      'Gaming ist wie eine Reise in andere Welten. Jedes neue Level bringt neue Abenteuer.\n',
      'Manchmal musst du einfach nur du selbst sein. Alle anderen gibt es ja schon, oder?\n',
      'Freundschaft bedeutet, dass man gemeinsam lacht, auch wenn nichts lustig ist. Keep smiling!\n',
      'Träume nicht dein Leben, sondern lebe deine Träume. Klingt kitschig, ist aber wahr.\n',
      'Sport macht den Kopf frei und gibt dir Energie. Egal ob Fußball, Tanzen oder Skaten.\n',
      'Musik ist die Sprache, die jeder versteht. Egal welche Sprache du sprichst.\n',
      'Chill mal deine Base, morgen ist auch noch ein Tag. Stress bringt einfach nichts.\n',
      'Abenteuer warten hinter jeder Ecke. Du musst nur die Augen offen halten und mutig sein.\n',
      'Kreativ sein heißt, Fehler als Chance zu sehen. Aus jedem Fail lernt man was Neues.\n'
    ];
  },

  _setupUI() {
    document.getElementById('btnStartGame').addEventListener('click', () => this.start());
  },

  start() {
    if (this._running) return;
    this._score = 0;
    this._combo = 0;
    this._maxCombo = 0;
    this._timeLeft = 60;
    this._running = true;

    // Pick random text
    const text = this._texts[Math.floor(Math.random() * this._texts.length)];
    // Repeat to have enough content
    const fullText = text.repeat(5);
    this._engine.loadText(fullText);
    this._engine.start();

    document.getElementById('scoreSpiel').textContent = '0';
    document.getElementById('comboCount').textContent = '0';
    document.getElementById('timerSpiel').textContent = '60';
    document.getElementById('timerSpiel').classList.remove('urgent');
    document.getElementById('cpmSpiel').textContent = '0';
    document.getElementById('accSpiel').textContent = '100%';
    document.getElementById('errSpiel').textContent = '0';
    document.getElementById('btnStartGame').textContent = 'Läuft...';
    document.getElementById('btnStartGame').disabled = true;

    // Blur button so global keyboard handler can capture keystrokes
    document.getElementById('btnStartGame').blur();

    // Timer
    this._timer = setInterval(() => this._tick(), 1000);
  },


  handleKey(key) {
    if (!this._running) return;
    if (key.length !== 1) return;
    const result = this._engine.handleKey(key);
    if (!result) return;

    if (result.correct) {
      this._combo++;
      if (this._combo > this._maxCombo) this._maxCombo = this._combo;
      const comboMultiplier = Math.min(this._combo, 10);
      const points = 10 * comboMultiplier;
      this._score += points;
      document.getElementById('scoreSpiel').textContent = this._score;

      if (this._combo >= 5) {
        document.getElementById('comboCount').textContent = this._combo + 'x';
        document.getElementById('comboSpiel').classList.add('combo-active');
        setTimeout(() => document.getElementById('comboSpiel').classList.remove('combo-active'), 200);
      }
      if (this._combo === 10 || this._combo === 20 || this._combo === 30) {
        this._spawnParticles();
      }
    } else {
      this._combo = 0;
      this._score = Math.max(0, this._score - 5);
      document.getElementById('scoreSpiel').textContent = this._score;
      document.getElementById('comboCount').textContent = '0';
    }
  },

  _tick() {
    this._timeLeft--;
    document.getElementById('timerSpiel').textContent = this._timeLeft;
    if (this._timeLeft <= 10) {
      document.getElementById('timerSpiel').classList.add('urgent');
    }
    if (this._timeLeft <= 0) {
      this._stop();
    }
  },

  _stop() {
    this._running = false;
    clearInterval(this._timer);
    this._timer = null;
    this._engine._finish();
    const stats = this._engine.getStats();
    this._onComplete(stats);
  },

  _onUpdate(stats) {
    document.getElementById('cpmSpiel').textContent = stats.cpm;
    document.getElementById('accSpiel').textContent = stats.accuracy + '%';
    document.getElementById('errSpiel').textContent = stats.errors;
  },

  _onComplete(stats) {
    document.getElementById('btnStartGame').textContent = 'Neues Spiel';
    document.getElementById('btnStartGame').disabled = false;
    document.getElementById('timerSpiel').classList.remove('urgent');

    const isNew = Stats.saveGameHighscore(this._score);
    const hs = Stats.getHighscore();

    let msg = `Zeit vorbei! ${stats.cpm} Anschläge/min, ${stats.accuracy}% Genauigkeit.\nPunkte: ${this._score}`;
    if (isNew) {
      msg += `\n🎉 NEUER HIGHSCORE: ${hs} Punkte!`;
    } else {
      msg += `\nHighscore: ${hs} Punkte`;
    }
    this._engine.displayText(msg.replace(/\n/g, '<br>'));

    // Celebration with rewards
    if (typeof Rewards !== 'undefined') {
      Rewards.celebrateGame(this._score, isNew, this._maxCombo);
    }
  },

  _spawnParticles() {
    const emojis = ['✨', '🌟', '💫', '🔥', '⚡', '💥', '🎯', '👑'];
    const display = document.getElementById('textDisplaySpiel');
    const rect = display.getBoundingClientRect();
    for (let i = 0; i < 8; i++) {
      const p = document.createElement('span');
      p.className = 'particle';
      p.textContent = emojis[Math.floor(Math.random() * emojis.length)];
      p.style.left = (rect.left + Math.random() * rect.width) + 'px';
      p.style.top = (rect.top + Math.random() * rect.height * 0.5) + 'px';
      p.style.animationDuration = (0.5 + Math.random() * 0.8) + 's';
      document.body.appendChild(p);
      setTimeout(() => p.remove(), 1000);
    }
  },

  get running() { return this._running; },
  get engine() { return this._engine; },

  destroy() {
    if (this._timer) clearInterval(this._timer);
    this._running = false;
  }
};
